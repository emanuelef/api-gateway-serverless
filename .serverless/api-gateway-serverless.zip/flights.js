(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded and loading wasm modules
/******/ 	var installedWasmModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// object with all compiled WebAssembly.Modules
/******/ 	__webpack_require__.w = {};
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 12);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("air-commons");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("source-map-support/register");

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/json/stringify");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/asyncToGenerator");

/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/regenerator");

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/get-iterator");

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/set");

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _getIterator2 = __webpack_require__(5);

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _set = __webpack_require__(6);

var _set2 = _interopRequireDefault(_set);

__webpack_require__(1);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _require$utils = __webpack_require__(0).utils,
    feetToMetres = _require$utils.feetToMetres,
    metresToFeet = _require$utils.metresToFeet,
    euclideanDistance = _require$utils.euclideanDistance,
    distFrom = _require$utils.distFrom,
    minDistancePointLine = _require$utils.minDistancePointLine;

var Flight = __webpack_require__(0).Flight;
var Position = __webpack_require__(0).Position;
var TimedPosition = __webpack_require__(0).TimedPosition;

var MAX_TIME_NO_NEW_DATA = 30; // in seconds

exports.genFlightsStats = function (allOrderedSamples, position) {
    var allFlights = [];
    var allSummaries = [];
    var toRemoveSet = new _set2.default();

    var populateAllSummaries = function populateAllSummaries(currentTimestamp, justRemainers) {
        var _iteratorNormalCompletion = true;
        var _didIteratorError = false;
        var _iteratorError = undefined;

        try {
            for (var _iterator = (0, _getIterator3.default)(allFlights), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                var flight = _step.value;

                var lastTimedPos = flight.getLastTimedPosition();
                if (lastTimedPos && lastTimedPos.timestamp > currentTimestamp + MAX_TIME_NO_NEW_DATA || justRemainers) {
                    var resSummary = flight.getSummary(position);

                    if (resSummary.samples > 2) {
                        allSummaries.push(resSummary);
                    }
                    //console.log(resSummary);
                    toRemoveSet.add(flight);
                }
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally {
            try {
                if (!_iteratorNormalCompletion && _iterator.return) {
                    _iterator.return();
                }
            } finally {
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }
    };

    var _loop = function _loop(sample) {

        var existingFlight = allFlights.find(function (f) {
            return f.icao === sample.icao;
        });

        var pos = new TimedPosition({
            lat: sample.latitude,
            lon: sample.longitude,
            alt: sample.galtM,
            timestamp: sample.time
        });

        if (existingFlight) {
            existingFlight.addTimedPosition(pos);
        } else {
            var currentFlight = new Flight(sample);
            currentFlight.addTimedPosition(pos);
            allFlights.push(currentFlight);
        }

        populateAllSummaries(pos.timestamp);

        allFlights = allFlights.filter(function (f) {
            return !toRemoveSet.has(f);
        });
        toRemoveSet = new _set2.default();
    };

    var _iteratorNormalCompletion2 = true;
    var _didIteratorError2 = false;
    var _iteratorError2 = undefined;

    try {
        for (var _iterator2 = (0, _getIterator3.default)(allOrderedSamples), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
            var sample = _step2.value;

            _loop(sample);
        }
    } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
    } finally {
        try {
            if (!_iteratorNormalCompletion2 && _iterator2.return) {
                _iterator2.return();
            }
        } finally {
            if (_didIteratorError2) {
                throw _iteratorError2;
            }
        }
    }

    populateAllSummaries(null, true);

    return allSummaries;
};

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("zlib");

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _stringify = __webpack_require__(2);

var _stringify2 = _interopRequireDefault(_stringify);

exports.success = success;
exports.failure = failure;
exports.successZipped = successZipped;

__webpack_require__(1);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function success(body) {
    return buildResponse(200, body);
}

function failure(body) {
    return buildResponse(500, body);
}

var buildResponse = function buildResponse(statusCode, body) {
    return {
        statusCode: statusCode,
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Credentials": true
        },
        body: (0, _stringify2.default)(body)
    };
};

function successZipped(gzippedResponse) {

    console.log(gzippedResponse.toString("base64"));

    return {
        statusCode: 200,
        "isBase64Encoded": true,
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Credentials": true,
            "Content-Encoding": "gzip"
        },
        body: gzippedResponse.toString("base64")
    };
}

/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = require("simple-statistics");

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.allFlightsInBox = exports.flights = exports.allInBox = exports.allZipped = exports.all = undefined;

var _getIterator2 = __webpack_require__(5);

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _stringify = __webpack_require__(2);

var _stringify2 = _interopRequireDefault(_stringify);

var _regenerator = __webpack_require__(4);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(3);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var all = exports.all = function () {
    var _ref = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(event, context, callback) {
        var qParams, items, picked;
        return _regenerator2.default.wrap(function _callee$(_context) {
            while (1) {
                switch (_context.prev = _context.next) {
                    case 0:
                        context.callbackWaitsForEmptyEventLoop = false;
                        qParams = event.queryStringParameters;
                        _context.prev = 2;
                        _context.next = 5;
                        return startQueryingPromise(qParams.from, qParams.to);

                    case 5:
                        items = _context.sent;

                        picked = function picked(_ref2) {
                            var latitude = _ref2.latitude,
                                longitude = _ref2.longitude,
                                galtM = _ref2.galtM,
                                time = _ref2.time;
                            return {
                                latitude: latitude,
                                longitude: longitude,
                                galtM: galtM,
                                time: time
                            };
                        };

                        if (qParams && qParams.latLonOnly) {
                            items = items.map(picked);
                        }
                        callback(null, (0, _responseLib.success)(items));
                        _context.next = 14;
                        break;

                    case 11:
                        _context.prev = 11;
                        _context.t0 = _context['catch'](2);

                        callback(null, (0, _responseLib.failure)({
                            status: false
                        }));

                    case 14:
                    case 'end':
                        return _context.stop();
                }
            }
        }, _callee, this, [[2, 11]]);
    }));

    return function all(_x, _x2, _x3) {
        return _ref.apply(this, arguments);
    };
}();

// Trying to zip directly as the option on AWS doesn't seem to work for me


var allZipped = exports.allZipped = function () {
    var _ref3 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(event, context, callback) {
        var qParams, items, picked, gzippedResponse;
        return _regenerator2.default.wrap(function _callee2$(_context2) {
            while (1) {
                switch (_context2.prev = _context2.next) {
                    case 0:
                        context.callbackWaitsForEmptyEventLoop = false;
                        qParams = event.queryStringParameters;
                        _context2.prev = 2;
                        _context2.next = 5;
                        return startQueryingPromise(qParams.from, qParams.to);

                    case 5:
                        items = _context2.sent;

                        picked = function picked(_ref4) {
                            var latitude = _ref4.latitude,
                                longitude = _ref4.longitude,
                                galtM = _ref4.galtM,
                                time = _ref4.time;
                            return {
                                latitude: latitude,
                                longitude: longitude,
                                galtM: galtM,
                                time: time
                            };
                        };

                        if (qParams && qParams.latLonOnly) {
                            items = items.map(picked);
                        }

                        _context2.next = 10;
                        return zipAsync((0, _stringify2.default)(items));

                    case 10:
                        gzippedResponse = _context2.sent;

                        //console.log(gzippedResponse.byteLength);
                        callback(null, (0, _responseLib.successZipped)(gzippedResponse));
                        _context2.next = 17;
                        break;

                    case 14:
                        _context2.prev = 14;
                        _context2.t0 = _context2['catch'](2);

                        //console.log(e.message);
                        callback(null, (0, _responseLib.failure)({
                            status: false
                        }));

                    case 17:
                    case 'end':
                        return _context2.stop();
                }
            }
        }, _callee2, this, [[2, 14]]);
    }));

    return function allZipped(_x4, _x5, _x6) {
        return _ref3.apply(this, arguments);
    };
}();

var allInBox = exports.allInBox = function () {
    var _ref5 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(event, context, callback) {
        var qParams, from, to, lat, lon, max, items;
        return _regenerator2.default.wrap(function _callee3$(_context3) {
            while (1) {
                switch (_context3.prev = _context3.next) {
                    case 0:
                        context.callbackWaitsForEmptyEventLoop = false;
                        qParams = event.queryStringParameters;
                        from = 1520216000;
                        to = 1530226800;
                        lat = 51.444137;
                        lon = -0.351227;
                        max = 1000;
                        _context3.prev = 7;
                        _context3.next = 10;
                        return startQueryingAllFilteredPromise(qParams.from, qParams.to, Number(qParams.lat), Number(qParams.lon), Number(qParams.max));

                    case 10:
                        items = _context3.sent;

                        callback(null, (0, _responseLib.success)(items));
                        _context3.next = 17;
                        break;

                    case 14:
                        _context3.prev = 14;
                        _context3.t0 = _context3['catch'](7);

                        callback(null, (0, _responseLib.failure)({
                            status: false
                        }));

                    case 17:
                    case 'end':
                        return _context3.stop();
                }
            }
        }, _callee3, this, [[7, 14]]);
    }));

    return function allInBox(_x7, _x8, _x9) {
        return _ref5.apply(this, arguments);
    };
}();

var flights = exports.flights = function () {
    var _ref6 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(event, context, callback) {
        var qParams, items;
        return _regenerator2.default.wrap(function _callee4$(_context4) {
            while (1) {
                switch (_context4.prev = _context4.next) {
                    case 0:
                        context.callbackWaitsForEmptyEventLoop = false;
                        qParams = event.queryStringParameters;
                        _context4.prev = 2;
                        _context4.next = 5;
                        return startQueryingFlightsPromise(qParams.from, qParams.to);

                    case 5:
                        items = _context4.sent;

                        callback(null, (0, _responseLib.success)(items));
                        _context4.next = 12;
                        break;

                    case 9:
                        _context4.prev = 9;
                        _context4.t0 = _context4['catch'](2);

                        callback(null, (0, _responseLib.failure)({
                            status: false
                        }));

                    case 12:
                    case 'end':
                        return _context4.stop();
                }
            }
        }, _callee4, this, [[2, 9]]);
    }));

    return function flights(_x10, _x11, _x12) {
        return _ref6.apply(this, arguments);
    };
}();

// http://localhost:3000/allFlightsInBox?from=1532101200&to=1532107600&lat=51.443874&lon=-0.342588&max=2500&minDistance=1200

var allFlightsInBox = exports.allFlightsInBox = function () {
    var _ref7 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(event, context, callback) {
        var qParams, items, flightsByIcao, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, item, reqPosition, allSummaries, belowMaxDistanceArray, belowMaxDistance, onlyMinDArray, medianDistance, meanDistance, minDistance, qRankTest, results;

        return _regenerator2.default.wrap(function _callee5$(_context5) {
            while (1) {
                switch (_context5.prev = _context5.next) {
                    case 0:
                        context.callbackWaitsForEmptyEventLoop = false;
                        qParams = event.queryStringParameters;
                        _context5.prev = 2;
                        _context5.next = 5;
                        return startQueryingAllFilteredPromise(qParams.from, qParams.to, Number(qParams.lat), Number(qParams.lon), Number(qParams.max));

                    case 5:
                        items = _context5.sent;
                        flightsByIcao = {};
                        _iteratorNormalCompletion = true;
                        _didIteratorError = false;
                        _iteratorError = undefined;
                        _context5.prev = 10;


                        for (_iterator = (0, _getIterator3.default)(items); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                            item = _step.value;

                            flightsByIcao[item.icao] = flightsByIcao[item.icao] || 0;
                            flightsByIcao[item.icao] = flightsByIcao[item.icao] + 1;
                        }

                        _context5.next = 18;
                        break;

                    case 14:
                        _context5.prev = 14;
                        _context5.t0 = _context5['catch'](10);
                        _didIteratorError = true;
                        _iteratorError = _context5.t0;

                    case 18:
                        _context5.prev = 18;
                        _context5.prev = 19;

                        if (!_iteratorNormalCompletion && _iterator.return) {
                            _iterator.return();
                        }

                    case 21:
                        _context5.prev = 21;

                        if (!_didIteratorError) {
                            _context5.next = 24;
                            break;
                        }

                        throw _iteratorError;

                    case 24:
                        return _context5.finish(21);

                    case 25:
                        return _context5.finish(18);

                    case 26:
                        reqPosition = new Position({
                            lat: Number(qParams.lat),
                            lon: Number(qParams.lon),
                            alt: 20 // TODO: Calculate right one
                        });
                        allSummaries = genFlightsStats(items, reqPosition);
                        belowMaxDistanceArray = allSummaries.filter(function (el) {
                            return el.minDistance < Number(qParams.minDistance);
                        });
                        belowMaxDistance = belowMaxDistanceArray.length;
                        onlyMinDArray = belowMaxDistanceArray.map(function (el) {
                            return el.minDistance;
                        });
                        medianDistance = belowMaxDistance > 0 ? ss.median(onlyMinDArray) : undefined;
                        meanDistance = belowMaxDistance > 0 ? ss.mean(onlyMinDArray) : undefined;
                        minDistance = belowMaxDistance > 0 ? ss.min(onlyMinDArray) : undefined;
                        qRankTest = belowMaxDistance > 0 ? ss.quantileRank(onlyMinDArray, medianDistance) : undefined;
                        results = {
                            belowMaxDistance: belowMaxDistance,
                            medianDistance: medianDistance,
                            meanDistance: meanDistance,
                            minDistance: minDistance,
                            qRankTest: qRankTest
                        };


                        if (!qParams.summaryOnly) {
                            results.belowMaxDistanceArray = belowMaxDistanceArray;
                        }

                        callback(null, (0, _responseLib.success)(results));
                        _context5.next = 44;
                        break;

                    case 40:
                        _context5.prev = 40;
                        _context5.t1 = _context5['catch'](2);

                        console.log(_context5.t1.message);
                        callback(null, (0, _responseLib.failure)({
                            status: false
                        }));

                    case 44:
                    case 'end':
                        return _context5.stop();
                }
            }
        }, _callee5, this, [[2, 40], [10, 14, 18, 26], [19,, 21, 25]]);
    }));

    return function allFlightsInBox(_x13, _x14, _x15) {
        return _ref7.apply(this, arguments);
    };
}();

__webpack_require__(1);

var _simpleStatistics = __webpack_require__(11);

var ss = _interopRequireWildcard(_simpleStatistics);

var _responseLib = __webpack_require__(10);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var zlib = __webpack_require__(9);

var _require = __webpack_require__(8),
    promisify = _require.promisify;

var zipAsync = promisify(zlib.gzip);

var _require$mysql = __webpack_require__(0).mysql,
    startQueryingPromise = _require$mysql.startQueryingPromise,
    startQueryingFlightsPromise = _require$mysql.startQueryingFlightsPromise,
    startQueryingAllFilteredPromise = _require$mysql.startQueryingAllFilteredPromise;

var Position = __webpack_require__(0).Position;

var _require2 = __webpack_require__(7),
    genFlightsStats = _require2.genFlightsStats;

/***/ })
/******/ ])));
//# sourceMappingURL=flights.js.map